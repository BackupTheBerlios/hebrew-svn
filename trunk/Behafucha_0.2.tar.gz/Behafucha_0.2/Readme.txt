Behafucha - Ver 0.2    4.11.2005

1. Behafucha:
   a. Convert English/Hebrew key strokes to Hebrew/English.
   b. Allow making mirror string from original string

2. In order to run "Behafucha" you need these dependencies:
   python, pythoncard, wxpython 

3. There are several ways to run "Behafucha":
   - Loading as system tray:
     You need to install the package 'alltray' and config it to launch 'Behafucha'

     For example:
     In Ububtu: system -> preferences -> sessions -> startup program -> add ->  python /path to/Behafucha.py
   - Creating Desktop/Taskbar shortcut
   - run the command (in terminal): python /path to/Behafucha.py

4. Changelog:
   Ver 0.2:
    - Changing the name of the software to "behafucha"
    - Creating only one button called 'Invert' instead of 2 separate buttons
    - Adding Copy + Paste Button
        - Cancel "ugly" code (elsif sequences...) and use dictionary structure instead
        - Changing the display background colour
    - Replacing the host project server to berlios
    - Automatic language recognition
    - Adding 'Behaficha.png' icon
    - Focus on the Textbox when launching the software (ready for typing or paste command)
   
       
Project Homepage: https://developer.berlios.de/projects/hebrew

Developed by: Shavit Ilan (ilan.shavit@gmail.com)
Licence: gpl
 
 

